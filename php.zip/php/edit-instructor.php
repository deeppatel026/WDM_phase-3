<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Connect to your MySQL database
$host = "51.81.160.154";
$username = "gxk1906_deep";
$password = "Deepwdm@123456";
$database = "gxk1906_WDM";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['instructorId'], $_POST['name'], $_POST['email'], $_POST['department'])) {
    $instructorId = $_POST['instructorId'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $department = $_POST['department'];

    // Update instructor in the database
    $sql = "UPDATE instructors SET name = '$name', email = '$email', department = '$department' WHERE id = $instructorId";

    if ($conn->query($sql) === TRUE) {
        $response = ['success' => true, 'message' => 'Instructor edited successfully'];
    } else {
        $response = ['success' => false, 'message' => 'Error editing instructor: ' . $conn->error];
    }

    echo json_encode($response);
}

$conn->close();
?>
